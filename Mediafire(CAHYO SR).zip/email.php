<?php

// GANTI NAMA WEB DI SETTING.PHP

$alexhost = 'emailmu@gmail.com'; // EMAIL KAMU

?>