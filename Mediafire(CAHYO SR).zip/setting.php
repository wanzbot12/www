<?php

$namafile = 'VIDEO VIRAL 2022'; // Nama File

$ukuran = '5MB'; //Ukuran file

$file = 'https://bit.ly/mediafire-terbaru'; // link mediafire asli/redirect

?>